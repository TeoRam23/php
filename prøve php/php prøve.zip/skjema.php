<form action="motta.php" method="GET">
    Hva heter du?
    <input type="text" name="navn">
    <br>
    Hva var inntekten din i 2020?
    <input type="number" name=inntekt2020>
    <br>
    Hva var inntekten din i 2021?
    <input type="number" name=inntekt2021>
    <br>
    Hva var inntekten din i 2022?
    <input type="number" name=inntekt2022>
    <br>

    <input type="submit" name="sendinn" value="Send inn">
</form>