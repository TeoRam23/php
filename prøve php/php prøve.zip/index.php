<?php
include "variabler.php";
echo "<br>";
include "if.php";
echo "<br>";
include "løkke.php";
echo "<br>";
include "løkker2.php";
echo "<br>";
include "skjema.php";
?>