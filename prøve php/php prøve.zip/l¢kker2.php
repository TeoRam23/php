<?php
for ($i=1; $i<=5; $i++) {
    for ($o=1; $o<=$i; $o++) {
        echo "* ";
    }
    echo"<br>";
}


?>