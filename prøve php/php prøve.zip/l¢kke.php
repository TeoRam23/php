<?php
for ($i=1; $i<=56; $i++) {
    if ($i == 23) {
        echo "Y";
    } else {
        echo "X";
    }
}


?>